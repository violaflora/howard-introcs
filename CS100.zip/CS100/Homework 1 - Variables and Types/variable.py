# Enter your code here
the_answer = int(42)

# Do not modify the lines below
print(type(the_answer))
print(the_answer)