# Your code here
the_answer = int(35)
the_answer += 7
# Do not modify the below
print(type(the_answer))
print(the_answer)