#prompt the user to enter their name 
name = input("Enter your name: ")
#prompt the user to enter their major 
major = input("What is your major? ")
#prompt the user to enter their university's name 
university = input("What university do you go to? ")

#print the required output below
print("I am " + name + " studying " + major + " at " + university + ".")