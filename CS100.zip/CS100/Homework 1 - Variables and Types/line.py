print("This is line 1")
print("This is line 2")