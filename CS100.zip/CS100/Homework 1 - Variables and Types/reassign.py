# declare my_variable with a string here. 
my_variable = 'hello'

# Do not modify lines 5 and 6. Reassign in line 8.
print(type(my_variable))
print(my_variable)

# Reassign my_variable here
my_variable = float(88.5)





# Do not modify the lines below
print(type(my_variable))
print(my_variable)
