# Your code here
my_string = "string"

# Do not modify the lines below
print(type(my_string))