a = int(input("Enter a number: ")) # To enter a number
b = int(input("Enter a different number: ")) # To enter a number different than the previous one.
c = None

# Do not modify the print statements here in line 5 and 6 
print("current value of a:", a)
print("current value of b:", b)

#swap the values assigned to these two variables without using numbers
# Your code!
c = a
a = b
b = c

# Do not modify the code below: 
print("value of a after swap:", a)
print("value of b after swap:", b)