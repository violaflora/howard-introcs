# Your code here! 
name = input("Enter your full name: ")
home = input("Enter the name of your hometown: ")
uni = input("Enter the name of your university: ")
classification = input("Enter your classification: ")
major = input("Enter your major: ")
print("My name is " + name + ". I am from " + home + ". I go to " + uni + ". I am a " + classification + " majoring in " + major + ".")