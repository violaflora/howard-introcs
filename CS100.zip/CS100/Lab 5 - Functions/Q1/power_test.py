import functions

print(functions.power(2, 5))
print(functions.power(4, 3))