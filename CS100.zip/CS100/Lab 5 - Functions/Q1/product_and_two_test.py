import functions

print(functions.product_and_two(4, 7))
print(functions.product_and_two(10, 7))
print(functions.product_and_two(9, 0))
