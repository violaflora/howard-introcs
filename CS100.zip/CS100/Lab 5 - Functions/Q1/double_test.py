import functions

print(functions.double(7))
print(functions.double(-9))