import functions

print(functions.is_negative(7))
print(functions.is_negative(-9))
print(functions.is_negative(0))