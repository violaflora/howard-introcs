import functions

print(functions.first_substr('Haystack', "stack"))
print(functions.first_substr('Hollywood', "Hollywoo"))
print(functions.first_substr('team', "eye"))