import functions

print(functions.is_palindrome('madam'))
print(functions.is_palindrome('sends'))
print(functions.is_palindrome('a man a plan a canal panama'))