import functions

print(functions.is_prime(19))
print(functions.is_prime(20))
print(functions.is_prime(41))
print(functions.is_prime(167))
print(functions.is_prime(227))