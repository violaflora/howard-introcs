import functions

print(functions.similar_words('effect', "affect"))
print(functions.similar_words('fishing', "bashing"))
print(functions.similar_words('HELLO', "hella"))
