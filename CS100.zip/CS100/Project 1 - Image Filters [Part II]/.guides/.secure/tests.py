import unittest
import filters
import image_io

class TestFilters(unittest.TestCase):
  def test_flip(self):
    input_matrix = image_io.read_file("test.png")
    result_matrix = filters.flip(input_matrix)
    solution_matrix = image_io.read_file("test_flipped.png")
    for i in range(len(solution_matrix)):
      for j in range(len(solution_matrix[i])):
        self.assertEqual(result_matrix[i][j], solution_matrix[i][j],
        msg="Got wrong pixel value at " + str((i,j)))
    
  def test_invert(self):
    input_matrix = image_io.read_file("test.png")
    result_matrix = filters.invert_colors(input_matrix)
    solution_matrix = image_io.read_file("test_inverted.png")
    self.assertEqual(result_matrix, solution_matrix)
    for i in range(len(solution_matrix)):
      for j in range(len(solution_matrix[i])):
        self.assertEqual(result_matrix[i][j], solution_matrix[i][j],
        msg="Got wrong pixel value at " + str((i,j)))
  
  def test_sepia(self):
    input_matrix = image_io.read_file("test.png")
    result_matrix = filters.sepia(input_matrix)
    solution_matrix = image_io.read_file("test_sepia.png")
    for i in range(len(solution_matrix)):
      for j in range(len(solution_matrix[i])):
        self.assertEqual(result_matrix[i][j], solution_matrix[i][j],
        msg="Got wrong pixel value at " + str((i,j)))
