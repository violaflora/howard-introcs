import movies
import unittest
from movies import add_or_update_a_movie, remove_actor_from_movie, find_movie_with_most_actors, find_actor_with_most_movies, parse_movie_text_file, degrees_between


class TestMovieActor(unittest.TestCase):
  def test_degrees_between(self):
    movie_dict = parse_movie_text_file("movies_large.txt")
    degrees = movies.degrees_between(movie_dict, "Richard Nixon", "Roger Deakins")
    self.assertEqual(degrees, -1)


