import movies
from movies import add_or_update_a_movie, remove_actor_from_movie, find_movie_with_most_actors, find_actor_with_most_movies, parse_movie_text_file
import unittest

class TestMovieActor(unittest.TestCase):
  def test_add_update_movies(self):

    movie_name = "Death of a Salesman"
    actors = ["Dustin Hoffman", "John Malkovich"]
    movie_name2 = "Rain Man"
    actors2 = ["Dustin Hoffman", "Tom Cruise"]
    movie_name3 = "The Godfather"
    actors3 = ["Al Pacino", "Robert De Niro", "Marlon Brando"]
    movie_name4 = "Crash"
    actors4 = ["Sandra Bullock", "Don Cheadle"]

    movies_dict = add_or_update_a_movie({}, movie_name, actors)
    movies_dict = add_or_update_a_movie(movies_dict, movie_name2, actors2)
    movies_dict = add_or_update_a_movie(movies_dict, movie_name3, actors3)
    movies_dict = add_or_update_a_movie(movies_dict, movie_name4, actors4)

    expected = {
                movie_name: actors,
                movie_name2: actors2,
                movie_name3: actors3,
                movie_name4: actors4
              }
    for m in expected:
        self.assertEqual(sorted(movies_dict[m]), sorted(expected[m]), msg="Got the wrong actors for " + m)
    

    movie_name = "Back to the Future"
    actors1 = ["Michael J Fox", "Christopher Lloyd"]
    actors2 = ["Thomas Wilson", "Lea Thompson"]
    actors3 = ["Mary Steenburgen"]

    movie_dict = movies.add_or_update_a_movie({}, movie_name, actors1)
    movie_dict = movies.add_or_update_a_movie(movie_dict, movie_name, actors2)
    movie_dict = movies.add_or_update_a_movie(movie_dict, movie_name, actors3)

    expected = {
            movie_name: [
              "Michael J Fox", 
              "Christopher Lloyd",
              "Thomas Wilson", 
              "Lea Thompson",
              "Mary Steenburgen"
              ]
        }
    for m in expected:
        self.assertEqual(sorted(movie_dict[m]), sorted(expected[m]), msg="Got the wrong actors for " + m)


    
  def test_find_actor_with_most_movies(self):
    ms = ['Down to You (2000)', 'Guide to Recognizing Your Saints, A (2006)', 'School of Rock, The (2003)', 'American Psycho (2000)', 'Pirates of the Caribbean: The Curse of the Black Pearl (2003)', 'Match Point (2005)', 'Men in Black II (2002)', "Devil's Rejects, The (2005)", 'Paparazzi (2004)', 'Good German, The (2006)', 'Rundown, The (2003)', 'Love in the Time of Money (2002)', 'Shattered Glass (2003)', 'Dirty Shame, A (2004)', 'Josie and the Pussycats (2001)', 'Chronicles of Riddick, The (2004)', 'Joe Somebody (2001)', 'Rent (2005)', 'Adventures of Pluto Nash, The (2002)', 'Nicholas Nickleby (2002)', 'Sin City (2005)', '25th Hour (2002)']
    actors = [['Rosario Dawson', 'Ashton Kutcher', 'Selma Blair'], ['Rosario Dawson'], ['Jack Black', 'Joan Cusack'], ['Josh Lucas', 'Willem Dafoe', 'Reese Witherspoon', 'Christian Bale'], ['Johnny Depp'], ['Brian Cox', 'Woody Allen'], ['Rosario Dawson', 'David Roehm Sr.', 'Johnny Knoxville', 'Will Smith', 'Greg Gardiner'], ['Rosario Dawson', 'John Tobin'], ['Vince Vaughn', 'Mel Gibson'], ['Steven Soderbergh', 'Steven Soderbergh', 'Cate Blanchett', 'George Clooney'], ['Christopher Walken', 'Rosario Dawson', 'Seann Scott'], ['Rosario Dawson', 'Steve Buscemi'], ['Rosario Dawson', 'Peter Sarsgaard'], ['Rick Kain', 'Johnny Knoxville', 'Selma Blair'], ['Eugene Levy', 'Rosario Dawson', 'Seth Green', 'Matthew Libatique', 'Alan Cumming'], ['Keith David', 'Vin Diesel', 'Judi Dench'], ['Hayden Panettiere'], ['Rosario Dawson', 'Taye Diggs'], ['Alec Baldwin', 'Rosario Dawson', 'Luis Guzman', 'Eddie Murphy', 'Oliver Wood'], ['Christopher Plummer'], ['Rosario Dawson', 'Robert Rodriguez', 'Robert Rodriguez'], ['Brian Cox', 'Rosario Dawson', 'Edward Norton', 'Rodrigo Prieto']]

    for i in range(len(ms)):
      print("Movies:", ms[i])
      print("Actors:", actors[i])
    movie_dict = {}
    for i in range(len(ms)):
      movie_dict = movies.add_or_update_a_movie(movie_dict, ms[i], actors[i])

    actor = movies.find_actor_with_most_movies(movie_dict)

    self.assertEqual(actor, "Rosario Dawson")

  def test_remove_actor_from_movie(self):
    movie_name = "Pee-Wee's Big Adventure"
    actors1 = ["Paul Reubens", "Phil Hartman"]
    actors2 = ["Paul Reubens", "Elizabeth Daily"]

    movie_dict = movies.add_or_update_a_movie({}, movie_name, actors1)
    movie_dict = movies.add_or_update_a_movie(movie_dict, movie_name, actors2)

    movie_dict = movies.remove_actor_from_movie(movie_dict, movie_name, "Paul Reubens")

    expected = {
                  movie_name: [
                    "Phil Hartman",
                    "Elizabeth Daily"
                  ]
              }
    for m in expected:
        self.assertEqual(sorted(movie_dict[m]), sorted(expected[m]), msg="Got the wrong actors for " + m)
    
  def test_find_movie_with_most_actors(self):
    ms = ['Johnson Family Vacation (2004)', 'Shaft (2000)', 'RV (2006)', "Charlotte's Web (2006)", 'Lara Croft Tomb Raider: The Cradle of Life (2003)', 'Sideways (2004)', 'Scoop (2006)', 'Constantine (2005)', 'New World, The (2005)', 'Thomas and the Magic Railroad (2000)']
    actors = [['Cedric the Entertainer'], ['Samuel Jackson', 'Jeffrey Wright', 'Christian Bale', 'Toni Collette'], ['Robin Williams'], ['Steve Buscemi', 'Cedric the Entertainer'], ['Angelina Jolie'], ['Paul Giamatti'], ['Scarlett Johansson', 'Woody Allen', 'Hugh Jackman'], ['Peter Stormare', 'Rachel Weisz'], ['Christopher Plummer', 'Colin Farrell', 'Christian Bale'], ['Alec Baldwin']]

    movie_dict = {}
    for i in range(len(ms)):
      movie_dict = movies.add_or_update_a_movie(movie_dict, ms[i], actors[i])

    actor = movies.find_movie_with_most_actors(movie_dict)

    self.assertEqual(actor, "Shaft (2000)")
  
  def test_find_similar_movies(self):
    ms = ['Royal Tenenbaums, The (2001)', 'Clearing, The (2004)', 'Mr. & Mrs. Smith (2005)', 'All Over the Guy (2001)', 'Quills (2000)', 'Maid in Manhattan (2002)', 'Men of Honor (2000)', 'National Treasure (2004)', 'Behind Enemy Lines (2001)', "Don't Say a Word (2001)", 'Gun Shy (2000)', 'Veronica Guerin (2003)']
    actors = [['Ben Stiller', 'Alec Baldwin', 'Owen Wilson', 'Luke Wilson', 'Gene Hackman', 'Gwyneth Paltrow'], ['Willem Dafoe'], ['Vince Vaughn', 'Angelina Jolie', 'Keith David', 'William Fichtner'], ['Adam Goldberg'], ['Michael Caine'], ['Stanley Tucci'], ['Robert De Niro', 'Charlize Theron'], ['Nicolas Cage', 'Christopher Plummer', 'Sean Bean'], ['Owen Wilson', 'Gene Hackman'], ['Sean Bean', 'Brittany Murphy'], ['Phil Hawn'], ['Cate Blanchett']]

    movie_dict = {}
    for i in range(len(ms)):
      movie_dict = movies.add_or_update_a_movie(movie_dict, ms[i], actors[i])

    matching_movies = movies.find_similar_movies(movie_dict, "Owen Wilson", "Gene Hackman")
    expected_movies = ['Behind Enemy Lines (2001)', 'Royal Tenenbaums, The (2001)']

    self.assertEqual(len(matching_movies), len(expected_movies), "Expected 2 movies, got " + str(len(matching_movies)))
    self.assertEqual(sorted(matching_movies), sorted(expected_movies))
  
  def test_parse_movie_text_file(self):

    movie_dict = movies.parse_movie_text_file("movies_large.txt")

    actor = movies.find_actor_with_most_movies(movie_dict)
    self.assertEqual(actor, "Rick Kain", msg="Incorrect most common actors")

    m = movies.find_similar_movies(movie_dict, "Sean Bean", "Cate Blanchett")
    expected_m = ['Lord of the Rings: The Return of the King', 'Lord of the Rings: The Two Towers', 'Lord of the Rings: The Fellowship of the Ring']
    self.assertEqual(sorted(m), sorted(expected_m), msg="Got incorrect Sean Bean/Cate Blanchett movies")

    movies_1 = movies.find_similar_movies(movie_dict, "Adam Sandler", "Rob Schneider")
    expected_movies_1 = ['Mr. Deeds (2002)', 'Eight Crazy Nights (2002)', 'Deuce Bigalow: European Gigolo (2005)', 'Click (2006/I)', '50 First Dates (2004)', 'Hot Chick']
    self.assertEqual(sorted(movies_1), sorted(expected_movies_1), msg="Got incorrect Adam Sandler/Rob Schneider movies")
  
  
