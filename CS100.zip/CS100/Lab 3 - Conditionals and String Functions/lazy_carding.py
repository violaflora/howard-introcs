# Please write your code here for Lazy Carding lab problem.
age = input("Enter your age: ")
if int(age) >= 21:
  print("You can order alcohol.")
else:
  print("You can\'t order alcohol. Thanks for being honest.")