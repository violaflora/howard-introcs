import filters
import image_io
import unittest

class TestFiltersI(unittest.TestCase):
  def test_grayscale(self):
    input_matrix = image_io.read_file("test.png")
    result_matrix = filters.grayscale(input_matrix)
    solution_matrix = image_io.read_file("test_grayscale.png")
    for i in range(len(solution_matrix)):
      for j in range(len(solution_matrix[i])):
        self.assertEqual(result_matrix[i][j], solution_matrix[i][j],
        msg="Got wrong pixel value at " + str((i,j))) 
    
  def test_stripe(self):
    input_matrix = image_io.read_file("test.png")
    result_matrix = filters.red_stripes(input_matrix)
    solution_matrix = image_io.read_file("test_stripe.png")

    for i in range(len(solution_matrix)):
      for j in range(len(solution_matrix[i])):
        self.assertEqual(result_matrix[i][j], solution_matrix[i][j],
        msg="Got wrong pixel value at " + str((i,j)))