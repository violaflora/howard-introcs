import book_analysis
import string

# Use this to call different module in book_analysis.py 
read_file()