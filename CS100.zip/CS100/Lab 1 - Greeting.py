# Ask the user to input their name with a prompt message "What is your name? " 
# Note the space after the questions mark in the prompt message. 
val = input("What is your name? ")
# Print out the user's name in this format "Hello, * user's name*"
print("Hello, " + val)