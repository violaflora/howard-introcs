from two_sum import two_sum

ans = two_sum([1, 4, 7, 9, 50], 100)
assert (ans is None) 