from two_sum import two_sum

ans = two_sum([1, 4, 7, 9], 11)
assert (ans == [1, 2] or ans == [2, 1]) 