import clean_list as c
print(c.clean_list([3, 0, 2, 8, 70, 0, 0, 43]))