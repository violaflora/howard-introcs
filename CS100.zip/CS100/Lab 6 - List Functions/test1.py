import coffee_shop_menu as c
print(c.make_menu(['Coffee', 'Decaf coffee', 'Muffin', 'Egg Sandwich'], [1.5, 1.5, 2.25, 3.0]))