import flip_transfer as f
original = ['hello', 'hi', 'hey there']
copy = []
f.flip_transfer_list(original, copy)
print(original)
print(copy)
