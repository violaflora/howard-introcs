from two_sum import two_sum

ans = two_sum([1, 2, 7, 9], 3)
assert (ans == [1, 0] or ans == [0, 1]) 