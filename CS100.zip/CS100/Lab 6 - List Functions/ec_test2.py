from two_sum import two_sum

ans = two_sum([1, 2, 7, 9], 10)
assert (ans == [3, 0] or ans == [0, 3]) 