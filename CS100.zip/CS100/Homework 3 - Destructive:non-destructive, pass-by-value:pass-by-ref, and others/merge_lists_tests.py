from merge_lists import merge_lists

def test_merge_lists():
    # Example test, this does not count as one of your tests
    assert merge_lists([1, 2, 3, 8], [2, 3, 5, 9, 12]) == [1, 2, 2, 3, 3, 5, 8, 9, 12]

    # Write tests below this line. Do not remove.
    # Follow the indent for this comment

    # Write tests above this line. Do not remove.

test_merge_lists()
